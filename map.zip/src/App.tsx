
import MapForm from './components/form/form'
import './App.css'
import MapComponent from './components/map/map'

function App() {
  


  return (
    <>
      {/* <MapForm /> */}
      <MapComponent/>
    </>
  )
  
}

export default App
